package patterns.creational.abstractFactory.furniture;

public interface Table
{
    void putSomethingOn(String article);
}
